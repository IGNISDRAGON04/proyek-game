using UnityEngine;

namespace Vampire
{
    public class CollectableType : ScriptableObject
    {
        public int inventoryStackSize = 0;
    }
}
