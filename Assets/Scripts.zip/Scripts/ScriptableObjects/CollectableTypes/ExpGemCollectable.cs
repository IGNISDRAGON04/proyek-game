using UnityEngine;

namespace Vampire
{
    [CreateAssetMenu(fileName = "Exp Gem", menuName = "CollectableTypes/Exp Gem", order = 1)]
    public class ExpGemCollectable : CollectableType {}
}
